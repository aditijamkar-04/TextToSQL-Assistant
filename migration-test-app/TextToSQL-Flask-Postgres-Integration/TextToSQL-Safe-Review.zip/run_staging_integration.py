"""Disposable Neon migration-test integration test for existing app user 26.
Run from the extracted integration project folder: python path/to/run_staging_integration.py
Never run against production. Does not print credentials.
"""
import os
import secrets
import sys
from pathlib import Path
from urllib.parse import urlsplit

from dotenv import load_dotenv

load_dotenv(r'D:\Projects\Py_SQL_Projects\TextToSQL-Assistant\.env', override=True)
test = os.getenv('MIGRATION_TEST_DATABASE_URL', '')
prod = os.getenv('DATABASE_URL', '')
if not test or not prod:
    sys.exit('STOP: Both database URLs must be configured')
th, ph = urlsplit(test).hostname, urlsplit(prod).hostname
if not th or th == ph or not th.startswith('ep-late-breeze-b4js7ehb'):
    sys.exit('STOP: Unexpected staging endpoint')
os.environ['DATABASE_URL'] = test
os.environ['WORKSPACE_BACKEND'] = 'postgres'
os.environ['POSTGRES_STAGING_READY'] = '1'
os.environ['DEMO_MODE'] = '1'

import psycopg
from psycopg import sql
from postgres_workspace_provisioning import provision_postgres_workspace, get_postgres_reader_password
from postgres_restricted_query import _reader_dsn, names, execute_restricted_select
from postgres_workspace_tables import (
    insert_workspace_record, view_workspace_records, modify_workspace_record,
    get_workspace_record_keys, list_workspace_tables,
)

user_id = 26
schema, role = names(user_id)
table = 'staging_check_' + secrets.token_hex(4)
created = False
password = get_postgres_reader_password(user_id)
print('Testing existing staging user 26; no credentials will be printed.')
try:
    with psycopg.connect(test, connect_timeout=10) as owner:
        with owner.cursor() as cur:
            cur.execute(sql.SQL('CREATE TABLE {}.{} (id INTEGER PRIMARY KEY, label VARCHAR(100))').format(sql.Identifier(schema), sql.Identifier(table)))
        created = True
    print('PASS: Disposable workspace table created')
    insert_workspace_record(user_id, table, {'id': 1, 'label': 'first'})
    assert view_workspace_records(user_id, table)['rows'] == [['1', 'first']]
    assert get_workspace_record_keys(user_id, table)['primary_keys'] == ['id']
    assert any(t['name'] == table for t in list_workspace_tables(user_id))
    print('PASS: Trusted CRUD insert, read, list, and primary-key discovery')
    modify_workspace_record(user_id, table, {'id': 1}, {'label': 'updated'})
    assert view_workspace_records(user_id, table)['rows'] == [['1', 'updated']]
    print('PASS: Trusted CRUD update')
    result = execute_restricted_select(f'SELECT id, label FROM "{schema}"."{table}"', user_id, password)
    assert result['rows'] == [[1, 'updated']]
    print('PASS: Actual table SELECT through restricted reader')
    with psycopg.connect(_reader_dsn(role, password), connect_timeout=10) as reader:
        with reader.cursor() as cur:
            assert cur.execute('SELECT current_user').fetchone()[0] == role
            cur.execute('SELECT has_table_privilege(current_user, %s, %s)', (f'{schema}.{table}', 'INSERT'))
            assert cur.fetchone()[0] is False, 'Reader unexpectedly has INSERT privilege'
            cur.execute('SELECT has_table_privilege(current_user, %s, %s)', (f'{schema}.{table}', 'UPDATE'))
            assert cur.fetchone()[0] is False, 'Reader unexpectedly has UPDATE privilege'
            cur.execute('SELECT has_table_privilege(current_user, %s, %s)', (f'{schema}.{table}', 'DELETE'))
            assert cur.fetchone()[0] is False, 'Reader unexpectedly has DELETE privilege'
    print('PASS: Reader cannot INSERT, UPDATE, or DELETE test table')
    try:
        execute_restricted_select(f'DELETE FROM "{schema}"."{table}"', user_id, password)
    except (ValueError, PermissionError):
        print('PASS: Generated SQL write rejected')
    else:
        raise AssertionError('Generated SQL write was accepted')
    modify_workspace_record(user_id, table, {'id': 1}, delete=True)
    assert view_workspace_records(user_id, table)['rows'] == []
    print('PASS: Trusted CRUD delete')
    again = provision_postgres_workspace(user_id)
    assert again['status'] == 'ready'
    assert get_postgres_reader_password(user_id) == password
    print('PASS: Idempotent provisioning retains reader credentials')
    print('ALL STAGING DATABASE INTEGRATION CHECKS PASSED')
finally:
    if created:
        with psycopg.connect(test, connect_timeout=10) as owner:
            with owner.cursor() as cur:
                cur.execute(sql.SQL('DROP TABLE IF EXISTS {}.{}').format(sql.Identifier(schema), sql.Identifier(table)))
        print('Cleanup: Disposable test table removed')
